-- Adminer 4.8.1 MySQL 8.0.32 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `binhLuan`;
CREATE TABLE `binhLuan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_phong` int DEFAULT NULL,
  `ma_nguoi_binh_luan` int DEFAULT NULL,
  `ngay_binh_luan` date DEFAULT NULL,
  `noi_dung` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `sao_binh_luan` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ma_phong` (`ma_phong`),
  KEY `ma_nguoi_binh_luan` (`ma_nguoi_binh_luan`),
  CONSTRAINT `binhLuan_ibfk_1` FOREIGN KEY (`ma_phong`) REFERENCES `phong` (`id`),
  CONSTRAINT `binhLuan_ibfk_2` FOREIGN KEY (`ma_nguoi_binh_luan`) REFERENCES `nguoiDung` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `binhLuan` (`id`, `ma_phong`, `ma_nguoi_binh_luan`, `ngay_binh_luan`, `noi_dung`, `sao_binh_luan`) VALUES
(2,	3,	3,	'2023-06-17',	'motasad3askdl;akd;adlal;skd;lak;ldasd',	4);

DROP TABLE IF EXISTS `datPhong`;
CREATE TABLE `datPhong` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_phong` int DEFAULT NULL,
  `ngay_den` datetime DEFAULT NULL,
  `ngay_di` datetime DEFAULT NULL,
  `so_luong_khach` int DEFAULT NULL,
  `ma_nguoi_dat` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ma_phong` (`ma_phong`),
  KEY `ma_nguoi_dat` (`ma_nguoi_dat`),
  CONSTRAINT `datPhong_ibfk_1` FOREIGN KEY (`ma_phong`) REFERENCES `phong` (`id`),
  CONSTRAINT `datPhong_ibfk_2` FOREIGN KEY (`ma_nguoi_dat`) REFERENCES `nguoiDung` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `datPhong` (`id`, `ma_phong`, `ngay_den`, `ngay_di`, `so_luong_khach`, `ma_nguoi_dat`) VALUES
(1,	1,	'2023-06-17 00:00:03',	'2023-06-18 00:00:03',	3,	4),
(2,	3,	'2023-06-17 00:00:03',	'2023-06-18 00:00:03',	3,	2);

DROP TABLE IF EXISTS `nguoiDung`;
CREATE TABLE `nguoiDung` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pass_word` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `birth_day` varchar(50) DEFAULT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `avatar` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `is_delete` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `nguoiDung` (`id`, `name`, `email`, `pass_word`, `phone`, `birth_day`, `gender`, `role`, `avatar`, `is_delete`) VALUES
(1,	'Admin',	'admin@gmail.com',	'abc1234',	'0989999999',	'18/01/1999',	1,	'Admin',	'1686878433239_Keanu_Reeves_2013_(10615146086)_(cropped).jpg',	NULL),
(2,	'test 1',	'test1@gmail.com',	'1236',	'12349875',	'01/02/1992',	1,	'User',	NULL,	NULL),
(3,	'Van A',	'vanA@gmail.com',	'abc1234',	'0989999999',	'18/01/1999',	1,	'Admin',	NULL,	NULL),
(4,	'Tien B',	'tienB@gmail.com',	'abc1234',	'987654321',	'08/55/2001',	0,	'User',	NULL,	NULL),
(5,	'Mod',	'mod@gmail.com',	'abc1234',	'987654321',	'08/55/2001',	0,	'Admin',	NULL,	NULL),
(6,	'Moder',	'moder@gmail.com',	'abc1234',	'222222222',	'08/55/2001',	1,	'Admin',	NULL,	NULL),
(7,	'do A',	'doa@gmail.com',	'222222',	'33333333',	'08/55/2001',	0,	'user',	NULL,	NULL),
(8,	'doB',	'dota@gmail.com',	'222222222',	'33333333',	'18/12/2001',	0,	'user',	NULL,	1),
(9,	'doP',	'dota23@gmail.com',	'222222222',	'33333333',	'18/12/2001',	0,	'User',	NULL,	NULL);

DROP TABLE IF EXISTS `phong`;
CREATE TABLE `phong` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ten_phong` varchar(50) DEFAULT NULL,
  `khach` int DEFAULT NULL,
  `phong_ngu` int DEFAULT NULL,
  `giuong` int DEFAULT NULL,
  `phong_tam` int DEFAULT NULL,
  `mo_ta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `gia_tien` int DEFAULT NULL,
  `may_giat` tinyint(1) DEFAULT NULL,
  `ban_la` tinyint(1) DEFAULT NULL,
  `tivi` tinyint(1) DEFAULT NULL,
  `dieu_hoa` tinyint(1) DEFAULT NULL,
  `wifi` tinyint(1) DEFAULT NULL,
  `bep` tinyint(1) DEFAULT NULL,
  `do_xe` tinyint(1) DEFAULT NULL,
  `ho_boi` tinyint(1) DEFAULT NULL,
  `ban_ui` tinyint(1) DEFAULT NULL,
  `ma_vi_tri` int DEFAULT NULL,
  `hinh_anh` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `is_delete` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ma_vi_tri` (`ma_vi_tri`),
  CONSTRAINT `phong_ibfk_1` FOREIGN KEY (`ma_vi_tri`) REFERENCES `viTri` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `phong` (`id`, `ten_phong`, `khach`, `phong_ngu`, `giuong`, `phong_tam`, `mo_ta`, `gia_tien`, `may_giat`, `ban_la`, `tivi`, `dieu_hoa`, `wifi`, `bep`, `do_xe`, `ho_boi`, `ban_ui`, `ma_vi_tri`, `hinh_anh`, `is_delete`) VALUES
(1,	'Five Star',	2,	1,	1,	1,	'mo ta gi day',	200,	1,	0,	1,	0,	1,	1,	1,	1,	1,	3,	'1686919242767_346142113_939875007339727_4012033227578981022_n.png',	NULL),
(2,	'Lottle',	4,	2,	2,	2,	'mo ta',	1000,	1,	1,	1,	1,	1,	1,	1,	1,	1,	2,	NULL,	NULL),
(3,	'NewApt D1 - Cozy studio - NU apt - 500m Bui Vien!',	3,	2,	1,	1,	'Tự nhận phòng\r\nTự nhận phòng bằng khóa thông minh.\r\nDinh Long là Chủ nhà siêu cấp\r\nChủ nhà siêu cấp là những chủ nhà có kinh nghiệm, được đánh giá cao và là những người cam kết mang lại quãng thời gian ở tuyệt vời cho khách.',	28,	1,	1,	1,	0,	1,	0,	1,	1,	1,	1,	NULL,	NULL);

DROP TABLE IF EXISTS `viTri`;
CREATE TABLE `viTri` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ten_vi_tri` varchar(50) DEFAULT NULL,
  `tinh_thanh` varchar(50) DEFAULT NULL,
  `quoc_gia` varchar(50) DEFAULT NULL,
  `hinh_anh` varchar(50) DEFAULT NULL,
  `is_delete` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `viTri` (`id`, `ten_vi_tri`, `tinh_thanh`, `quoc_gia`, `hinh_anh`, `is_delete`) VALUES
(1,	'Thành Phố Hồ Chí Minh',	'Thành phố Hồ Chí Minh',	'Việt Nam',	'1686882370135_JPEG_example_flower.jpg',	NULL),
(2,	'Nha Trang',	'Khánh Hòa',	'Việt Nam',	NULL,	NULL),
(3,	'Đà Lạt',	'Lâm Đồng',	'Việt Nam',	NULL,	NULL),
(4,	'Vũng Tàu',	'Bà Rịa - Vũng Tàu',	'Việt Nam',	NULL,	NULL),
(5,	'Cần Thơ',	'Cần Thơ',	'Việt Nam',	NULL,	NULL);

-- 2023-06-19 07:38:35
